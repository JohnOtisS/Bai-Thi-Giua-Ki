package edu.uef.thithuchanh;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ListView lvProgram;
    String[] programName = {"beer", "bread", "cherrycheesecake", "hamburger", "sunnysideupeggs", "coconutcocktail", "gingerbreadhouse", "lemonade", "milkshake", "orangejuice"};
    String[] programDescription = {"beer Description", "bread Description", "cherrycheesecake Description","hamburger Description", "sunnysideupeggs Description",
            "coconutcocktail Description", "gingerbreadhouse Description", "lemonade Description",
            "milkshake Description", "orangejuice Description"};
    int[] programImages = {R.drawable.beer, R.drawable.bread,
            R.drawable.cherrycheesecake, R.drawable.hamburger, R.drawable.sunnysideupeggs,
            R.drawable.coconutcocktail, R.drawable.gingerbreadhouse, R.drawable.lemonade,
            R.drawable.milkshake, R.drawable.orangejuice};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lvProgram = findViewById(R.id.lvProgram);
        ProgramAdapter programAdapter = new ProgramAdapter(this, programName, programImages, programDescription);
        lvProgram.setAdapter(programAdapter);
    }
}